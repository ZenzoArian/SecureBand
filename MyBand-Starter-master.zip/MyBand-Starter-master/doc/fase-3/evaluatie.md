# Evaluatie

Wat ging er goed:<br>
Het ging erg goed om de informatie uit de database te halen en er goed uit te laten zien.
<br><br>
Waar had je moeite mee:<br>
Ik had veel moeite met gebruik maken van Grid’s
<br><br>
Haalde je de oplevermomenten in je planning? Waarom wel / niet?:<br>
Ja ik ging zelfs een klein beetje sneller dan mijn planning. Dit kwam hoog waarschijnlijk doordat al een beetje ervaring had door vorige projecten.
<br><br>
Hoe ging de communicatie met de betrokkenen:<br>
Erg goed. Helaas kwam het wel vaak voor dat docent niet allemaal op de hoogte waren van wat wel moest en wat niet. Dit zorgde voor verwarring.
<br><br>
Wat zou je anders doen:<br>
Ik zou meer moeite moeten stoppen in het gebruiken van Grid’s en ook een betere thema voor mijn website ontwerpen.

