# Gebruikersdocumentatie

Het is erg gemakkelijk om mijn site te gebruiken.<br><br>
Wanneer je op de ‘home’ pagina komt kan je omlaag scrollen voor alle video’s. Om meer video’s te zien kan je op de paginanummers drukken zodat je de volgende drie video’s kan zien.<br><br>
Als je met je muis over ‘Other’ gaat zie je een dropdown met meerdere keuzes als je op ‘Search’ drukt kom je op een pagina waar je de titel van een video kan intypen en dan op ENTER of op de search knop kan drukken zodat je alleen de bijpassende video’s ziet.<br><br>
Je kan ook naar ‘Agenda’ gaan. Selecteer hier de dag en zie meteen op welke dagen er iets op de website wordt geplaatst.<br><br>
Als je met je muis over ‘More gaat zie je een dropdown met meerdere keuzes als je op ‘About us’ drukt kom je op een pagina waar extra informatie over de website staat.<br><br>
Druk je op ‘Contact’ dan kan je een bericht sturen naar de makers van de website.<br><br>
Druk je op ‘Channels’ dan zie je alle kanalen die zich op deze website bevinden.<br><br>
Druk je op ‘Projects’ dan zie je andere projecten van de maker van de website.



