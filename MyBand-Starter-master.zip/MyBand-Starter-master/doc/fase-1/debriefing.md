# Debriefing

Schrijf in dit document de debriefing voor jouw MyBand project

* Wat is volgens jou de opdracht?                                                                             
De opdracht is om een website te maken waarop tekst met illustraties staan. Deze teksten moet echter te zoeken zijn met een zo genaamde searchbar. 
______________________
* Wat wordt er gevraagd?                                                          
Er wordt gevraagd om een website te maken met mijn eigen onderwerp waarbij deze berichten op te zoeken zijn en de structuur van mijn code moet op de MVC manier gedaan zijn.
______________________
* Welke globale planning is er?                                                                             
De globale planning is dat ik één opdracht per week doe en de laatste 3 weken de functionele website maak.
______________________
* Wat zijn je eerste ideeën voor jouw project?                                                        
Ik heb als idee om leuke video’s en teksten op mijn website te zetten die leuke en interessante informatie aan mensen uitleggen. Mijn onderwerp wordt dus: leuke en leerzame video’s.


*Hulp*
* http://mi.hosts.ma-cloud.nl/iv/fase3/trainingen/briefing_debriefing/
* [Voorbeeld structuur debriefing](http://members.quicknet.nl/p.devries1/OpzetDebriefing.pdf)
