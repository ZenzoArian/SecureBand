# PLANNING MY Band
Neem je urenschatting en zet deze uit tegen de uren in de week die je beschikbaar hebt. Om het aantal uren te vinden, kijk je op magister
Zet de onderdelen in je eigen rooster en let daarbij op deadlines. Plan niet te strak: houdt rekening met onverwachte vertragingen.
Deze planning is een levend document (blijven aanpassen aan de werkelijke situatie).

(je mag ook een eigen planningstool gebruiken, zo lang je hier je planning maar deelt)

*Dit is versie 0.0*

##### WEEK 1
|         | ma 6/5 | di 7/5 | wo 8/5 | do 9/5 | vr 10/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur  | | | | | |  |
| 3de uur  | | | | | |  |
| 4de uur  | | | | | |  |
| 5de uur  | | | | | |  |
| 6de uur  | | | | | |  |
| 7de uur  | | | | | |  |
| 8de uur  | | | | | |  |

##### WEEK 2
|         | ma 13/5 | di 14/5 | wo 15/5 | do 16/5 | vr 17/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | STUDIEDAG | |  |
| 2de uur  | | | | STUDIEDAG | |  |
| 3de uur  | | | | STUDIEDAG | |  |
| 4de uur  | | | | STUDIEDAG | |  |
| 5de uur  | | | | STUDIEDAG | |  |
| 6de uur  | | | | STUDIEDAG | |  |
| 7de uur  | | | | STUDIEDAG | |  |
| 8de uur  | | | | STUDIEDAG | |  |

##### WEEK 3
|         | ma 20/5 | di 21/5 | wo 22/5 | do 23/5 | vr 24/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | | U0004 |
| 2de uur  | | | | U0004| |  |
| 3de uur  | | B0003| | | |  |
| 4de uur  | | | | |B0009 |  |
| 5de uur  | | | | | | U0004 |
| 6de uur  | | | U0004| | | U0002 |
| 7de uur  | | | U0004| | | U0002 |
| 8de uur  | B0009| | | | |  |

##### WEEK 4
|         | ma 27/5 | di 28/5 | wo 29/5 | do 30/5 | vr 31/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | U0003	| | HEMELVAART | |  |
| 2de uur  | | | | HEMELVAART | |  |
| 3de uur  | | |B0003 | HEMELVAART | |  |
| 4de uur  | | | | HEMELVAART | |  |
| 5de uur  | | | | HEMELVAART | | U0003	 |
| 6de uur  | | U0003	| | HEMELVAART | |  |
| 7de uur  | | | | HEMELVAART | |  |
| 8de uur  | |U0003	 | | HEMELVAART | |  |

##### WEEK 5
|         | ma 3/6 | di 4/6 | wo 5/6 | do 6/6 | vr 7/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | U0007| | | |  |
| 3de uur | | | | | U0001	|  |
| 4de uur | | | | | |  |
| 5de uur | | U0007| | | |  |
| 6de uur | U0001	| | | | |  |
| 7de uur | | | | U0007| |  |
| 8de uur | | | U0001	| | |  |

##### WEEK 6
|         | ma 10/6 | di 11/6 | wo 12/6 | do 13/6 | vr 14/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | GEEN LES | |  |
| 2de uur | | B0004| | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | B0004|  |
| 6de uur | | | | | | B0004 |
| 7de uur | | | B0004| | |  |
| 8de uur | | | | | |  |


##### WEEK 7
|         | ma 17/6 | di 18/6 | wo 19/6 | do 20/6 | vr 21/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | B0009| | | |  |
| 3de uur | | | | | | B0009 |
| 4de uur | | | | | |  |
| 5de uur | |B0009 | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | |U0007	 | |  |
| 8de uur | | | | | |  |

