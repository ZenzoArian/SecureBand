# Urenschatting

Ik schat dat ik ongeveer 3 weken bezig ga zijn met mijn project.
