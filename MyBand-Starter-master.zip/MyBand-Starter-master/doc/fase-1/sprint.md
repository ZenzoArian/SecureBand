13 – 17 mei 2019 <br>
Planning sprint 1<br><br>
3 20 – 24 mei 2019<br>
Sprint 1 <br>Opleveren Sprint 1<br>
Planning sprint 2<br><br>
4 27 – 31 mei 2019<br>
Sprint 2 <br>Opleveren Sprint 2<br>
Planning Sprint 3<br><br>
5 3 – 7 juni 2019<br>
Sprint 3 <br>Opleveren Sprint 3
