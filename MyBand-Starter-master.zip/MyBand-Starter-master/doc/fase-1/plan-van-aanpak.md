# Plan van aanpak

Ik ben van plan om een website te maken met informatieve video’s die ik op het internet heb gevonden. Dit ga ik doen door de video’s op mijn website te plaatsen met informatie erbij. <br><br>
•	Eerst ga ik een database maken waar ik mijn video’s en informatie in kan zetten.<br>
•	Dan maak ik een script dat die data uit een database kan halen en online laat zien.<br>
•	Dan maak ik dat je de inhoud kan doorzoeken door de titel in te typen.<br>
•	Daarna voeg ik paginanummers toe aan de website.<br>
•	Als dat gelukt is maak ik een agenda die werkt met behulp van Ajax.<br>
•	Dan maak ik vier extra informatiepagina’s waarvan eentje grid gebruikt.<br>
•	Dan stijl ik de gehele pagina.<br>
•	Als laatste zet ik de website online en controleer of alles het nog doet en wat ik weer moet maken.<br>
