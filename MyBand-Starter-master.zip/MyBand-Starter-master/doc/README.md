# Documentatie

In deze directory zet je per week al je project documentatie:

- Debriefing
- Project plan
- User stories
- Functioneel ontwerp + wireframes
- Technisch ontwerp
- Ontwerpen documenten
- Flowcharts / Wirefframes
- Schermontwerpen
- (Sprint) planning / Logboek
- etc. etc.

Lees het document [README] in de hoofdmap van dit project voor een overzicht.

[README]: <../README.md>  
