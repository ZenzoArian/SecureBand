<?php

$link = "http://localhost/PROJ/myBand/public/";

 ?>
