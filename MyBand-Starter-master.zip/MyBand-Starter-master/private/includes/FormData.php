<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/FormStyle.css">
  <title>Forms opdracht</title>
</head>

<body>
  <div class="around">
    <h2>Any questions?</h2>
    Contact us! <br><br>
    Email address <br>
    <input type="text" name="" value=""><br><br>
    Message <br>
    <textarea name="text" rows="7" cols="35"></textarea>
    <br>
    <button type="button" class="SendBut" name="button" onclick="send()">Send message</button>
  </div>
<script src="js/FormScript.js"></script>
</body>

</html>
