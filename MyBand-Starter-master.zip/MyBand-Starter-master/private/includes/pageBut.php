<?php
echo '
<div class="buttonsDiv">

<div class="ButtonPage" onclick="page1()">1</div>
<div class="ButtonPage" onclick="page2()">2</div>
<div class="ButtonPage" onclick="page3()">3</div>
<div class="ButtonPage" onclick="page4()">4</div>
<div class="ButtonPage" onclick="page5()">5</div>
<div class="ButtonPage" onclick="page6()">6</div>
<div class="ButtonPage" onclick="page7()">7</div>
<div class="ButtonPage" onclick="page8()">8</div>
<div class="ButtonPage" onclick="page9()">9</div>
<div class="ButtonPage" onclick="page10()">10</div>

</div>
';

 ?>
