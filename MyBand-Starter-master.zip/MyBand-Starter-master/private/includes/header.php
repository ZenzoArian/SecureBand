<?php echo '
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <link rel="stylesheet" href="css/contentStyle.css">
	<link rel="stylesheet" href="css/headerStyle.css">
	<link rel="stylesheet" href="css/PagenumberStyle.css">
	<link rel="stylesheet" href="css/footerStyle.css">
  <link rel="stylesheet" href="css/agendaStyle.css">
  <link rel="stylesheet" href="css/SearchStyle.css">
  <link rel="stylesheet" href="css/AboutUsStyle.css">
  <link rel="stylesheet" href="css/channelStyle.css">
  <link rel="stylesheet" href="css/projectsStyle.css">
  <link rel="shortcut icon" href="uploads/logo.png">
  <script src="js/pageScript.js"></script>
	<script src="js/pageScript.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
' ?>
