<?php
echo '
<ul>
  <li class="dropdown" id="top">
    <a href="javascript:void(0)" class="dropbtn">More &#x25BC;</a>
    <a href="javascript:void(0)" class="dropbtn2">More &#x25B2;</a>
    <div class="dropdown-content">
      <a href="about">About us</a>
			<a href="contact">Contact</a>
			<a href="channel">Channels</a>
			<a href="projects">Projects</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Other page &#x25BC;</a>
    <a href="javascript:void(0)" class="dropbtn2">Other page &#x25B2;</a>
    <div class="dropdown-content">
      <a href="home">Home</a>
      <a href="search">Search</a>
      <a href="agenda">Agenda</a>
    </div>
  </li>
</ul>
';


 ?>
