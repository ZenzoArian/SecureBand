# Views (ook wel templates)

Hier zet je al je "templates". De templates zorgen voor de uitvoer van de gegevens die opgevraagd worden.
De controller haalt de gegevens op via het *Model* en geeft ze aan de *View* zodat ze getoond kunnen worden.
De views bevatten dus geen logica en geven alleen gegevens weer (in HTML, JSON, CSV, PDF)

De data wordt door de controller opgehaald via het "model" (die dingen uit de database ophaalt bijvoorbeeld) 
De data wordt vervolgens aan de view gegeven die ervoor zorgt dat het op de juiste manier wordt weergegeven.