## Titel van jouw website
https://zenzo-arian.com/myBand/public/ is een website van Zenzo X. Arian genaamd: SmartTube, waar gebruikers leuke en informatieve video's kunnen bekijken bedoeld voor jongeren en ouderen.
De website is enigszins te vergelijken met youtube of TED talks maar toch anders omdat mijn website precieze en korte video's heeft die allemaal geanimeerd  zijn.

### Uniek aan dit concept is: 
 * Mijn website gaat over meerdere onderwerpen en thema's.
 * Mensen zullen de leuke video's die je niet vaak ziet onthouden.

---
#### Milestones 

In het [Kwalificatiedossier] voor de opleiding Mediadeveloper staan een aantal *kerntaken* en *werkprocessen*.
In onderstaande tabel zie je per kerntaak en werkproces welke werkzaamheden en documenten hier bij horen.
Elke opgeleverd product of document is een *milestone*, een belangrijke stap die nodig is bij de ontwikkeling van jouw MyBand project.

![kerntaken en werkprocessen](doc/images/kd_taken_processen.png)

Je wordt beoordeeld op de aanwezigheid en inhoud van onderstaande documenten.

##### Fase 1: Opdracht vaststellen / Projectplan en planning / Ontwerpen & voorbereiden 

Deze fase duurt 3 weken

| Milestone  | Status | Link | Type Document of cloudservice |
| ------ |  ------ | ------ | ------ |
| README                                            | DONE | [README.md]  (dit document)          | MarkDown |
| B1-K1-W1 Debriefing                               | DONE | [Debriefing]                         | Markdown |
| B1-K1-W2 Planning                                 | DONE | [Planning]                           | Markdown |
| B1-K1-W2 Plan van aanpak                          | DONE | [Plan van Aanpak]                    | Markdown of Word/RTF|
| B1-K1-W2 User stories                             | DONE | [User Stories]                       | Markdown of Word/RTF|
| B1-K1-W2 Functioneel ontwerp                      | DONE | [FO]                                 | Markdown of Word/RTF|
| B1-K1-W2 Flowchart                                | DONE | [Flow]                               | Afbeelding(en) of geexporteerd uit http://draw.io |
| B1-K1-W2 Urenschatting                            | DONE | [Urenschatting]                      | Markdown |
| B1-K1-W2 Wireframes en/of Interactief prototype   | DONE | [axShare]                            | Axshare link of link naar ander online prototype tool |
| B1-K1-W2 Sfeer impressie / schermontwerpen        | DONE | [Design]                             | Afbeeldingen |

[Kwalificatiedossier]: https://kwalificaties.s-bb.nl/Handlers/DocumentLibrary.ashx?id=276758
[README.md]: <https://github.com/JouwGithubNaam/myband/blob/master/README.md>
[Debriefing]: <doc/fase-1/debriefing.md>
[Planning]: <doc/fase-1/planning.md>
[Plan van Aanpak]: <doc/fase-1/plan-van-aanpak.md>
[User stories]: <doc/fase-1/user-stories.md>
[Design]: <doc/fase-1/design/design.md/>
[FO]: </doc/fase-1/Functioneel ontwerp.rp>
[Flow]: <doc/fase-1/flowchart.PNG>
[Urenschatting]: <doc/fase-1/urenschatting.md>
[axShare]: <https://cp9o2w.axshare.com/#g=1&p=home>

#### Fase 2: Realiseren van de opdracht (in sprints)

| Milestone  | Status | Link |
| ------ |  ------ | ------ |
| B1-K1-W2 Product backlog                          | DONE | [Backlog]                            | Link naar Trello met Sprint planningen | |
| B1-K1-W2 Sprint planning 1, 2 en 3                | DONE | [Sprint Planning]          | Link naar Trello met Sprint planningen | |
| B1-K1-W3 Technisch Ontwerp                        | DONE | [TO]                                 | Markdown of Word/RTF| |

[Backlog]: </doc/fase-1/backlog.md>
[TO]: </doc/fase-2/technisch-ontwerp.md>
[Sprint Planning]: </doc/fase-1/sprint.md>
   
#### Fase 3: Testen en opleveren van het project

| Milestone  | Status | Link |
| ------ |  ------ | ------ |
| B1-K3-W2 Link naar de live omgeving                        |  DONE |  <https://zenzo-arian.com/myBand/public/> |
| B1-K3-W2 Gebruikersdocumentatie / instructie               |  DONE |  [Gebruikers documentatie] |
| B1-K3-W3 Evaluatie                                         |  DONE |  [Evaluatie] |

[Gebruikers documentatie]: <doc/fase-3/gebruikersdocumentatie.md>
[Evaluatie]: <doc/fase-3/evaluatie.md>
