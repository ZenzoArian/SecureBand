function page1() {
  document.getElementById('top').scrollIntoView();
  // document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem1").style.display = "block";

}function page2() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  // document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem2").style.display = "block";

}function page3() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  // document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem3").style.display = "block";

}function page4() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  // document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem4").style.display = "block";

}function page5() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  // document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem5").style.display = "block";

}function page6() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  // document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem6").style.display = "block";

}function page7() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  // document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem7").style.display = "block";

}function page8() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  // document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  // document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem8").style.display = "block";

}function page9() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  // document.getElementById("pageItem9").style.display = "none";
  document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem9").style.display = "block";

}function page10() {
  document.getElementById('top').scrollIntoView();
  document.getElementById("pageItem1").style.display = "none";
  document.getElementById("pageItem2").style.display = "none";
  document.getElementById("pageItem3").style.display = "none";
  document.getElementById("pageItem4").style.display = "none";
  document.getElementById("pageItem5").style.display = "none";
  document.getElementById("pageItem6").style.display = "none";
  document.getElementById("pageItem7").style.display = "none";
  document.getElementById("pageItem8").style.display = "none";
  document.getElementById("pageItem9").style.display = "none";
  // document.getElementById("pageItem10").style.display = "none";
  document.getElementById("pageItem10").style.display = "block";

}
